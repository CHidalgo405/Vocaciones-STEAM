import { Component, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { LucideAngularModule, Brain, Compass, MapPin, Rocket, Facebook, Twitter, Instagram, Linkedin, LUCIDE_ICONS, LucideIconProvider } from 'lucide-angular';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);
@Component({
  selector: 'app-home',
  imports: [
    LucideAngularModule
  ],
  providers: [
    { provide: LUCIDE_ICONS, useValue: new LucideIconProvider({ Brain, Compass, MapPin, Rocket, Facebook, Twitter, Instagram, Linkedin }) }
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
  standalone: true,
})
export class PwaHomeComponent implements AfterViewInit {
  quotes = [
    { text: 'Encontré mi camino', img: 'assets/student1.jpg' },
    { text: 'La IA me sorprendió', img: 'assets/student2.jpg' }
  ];

  ngAfterViewInit() {
    // Animación de Título (Efecto Reveal)
    gsap.from('.reveal-text', {
      duration: 1.5,
      y: 100,
      opacity: 0,
      ease: 'power4.out',
      delay: 0.5
    });

    // Animación de la Info Card al hacer Scroll (Individualmente)
    gsap.utils.toArray('.info-container').forEach((container: any) => {
      gsap.from(container, {
        scrollTrigger: {
          trigger: container,
          start: 'top 80%',
          end: 'top 30%',
          scrub: 1
        },
        scale: 0.8,
        opacity: 0,
        duration: 2
      });
    });

    // Efecto Parallax en la imagen de info
    gsap.to('.info-image img', {
      scrollTrigger: {
        trigger: '.info-image',
        scrub: true
      },
      y: -50
    });
  }
}